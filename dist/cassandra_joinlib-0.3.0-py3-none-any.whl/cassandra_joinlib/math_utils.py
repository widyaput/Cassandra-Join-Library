def bit_to_byte(b):
    as_byte = b / 8

    return as_byte

def byte_to_kilobyte(b):
    as_kb = b / (1e3)

    return as_kb

def kilobyte_to_byte(KB):

    return KB * 1e3

def byte_to_megabyte(b):
    as_mb = b / (1e6)

    return as_mb

def megabyte_to_byte(MB):

    return MB * 1e6

def byte_to_gigabyte(b):
    as_gb = b / (1e9)

    return as_gb

def gigabyte_to_byte(GB):

    return GB * 1e9